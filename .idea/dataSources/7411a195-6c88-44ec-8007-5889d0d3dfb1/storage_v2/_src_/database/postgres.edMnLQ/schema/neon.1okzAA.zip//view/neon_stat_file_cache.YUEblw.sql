create view neon_stat_file_cache
            (file_cache_misses, file_cache_hits, file_cache_used, file_cache_writes, file_cache_hit_ratio) as
WITH lfc_stats AS (SELECT t.stat_name,
                          t.count
                   FROM neon.neon_get_lfc_stats() t(stat_name text, count bigint)),
     lfc_values AS (SELECT max(
                                   CASE
                                       WHEN lfc_stats.stat_name = 'file_cache_misses'::text THEN lfc_stats.count
                                       ELSE NULL::bigint
                                       END) AS file_cache_misses,
                           max(
                                   CASE
                                       WHEN lfc_stats.stat_name = 'file_cache_hits'::text THEN lfc_stats.count
                                       ELSE NULL::bigint
                                       END) AS file_cache_hits,
                           max(
                                   CASE
                                       WHEN lfc_stats.stat_name = 'file_cache_used'::text THEN lfc_stats.count
                                       ELSE NULL::bigint
                                       END) AS file_cache_used,
                           max(
                                   CASE
                                       WHEN lfc_stats.stat_name = 'file_cache_writes'::text THEN lfc_stats.count
                                       ELSE NULL::bigint
                                       END) AS file_cache_writes,
                           CASE
                               WHEN (max(
                                             CASE
                                                 WHEN lfc_stats.stat_name = 'file_cache_misses'::text
                                                     THEN lfc_stats.count
                                                 ELSE 0::bigint
                                                 END) + max(
                                             CASE
                                                 WHEN lfc_stats.stat_name = 'file_cache_hits'::text THEN lfc_stats.count
                                                 ELSE 0::bigint
                                                 END)) = 0 THEN NULL::numeric
                               ELSE round(max(
                                                  CASE
                                                      WHEN lfc_stats.stat_name = 'file_cache_hits'::text
                                                          THEN lfc_stats.count
                                                      ELSE 0::bigint
                                                      END)::numeric / (max(
                                                                               CASE
                                                                                   WHEN lfc_stats.stat_name = 'file_cache_hits'::text
                                                                                       THEN lfc_stats.count
                                                                                   ELSE 0::bigint
                                                                                   END) + max(
                                                                               CASE
                                                                                   WHEN lfc_stats.stat_name = 'file_cache_misses'::text
                                                                                       THEN lfc_stats.count
                                                                                   ELSE 0::bigint
                                                                                   END))::numeric * 100::numeric, 2)
                               END          AS file_cache_hit_ratio
                    FROM lfc_stats)
SELECT file_cache_misses,
       file_cache_hits,
       file_cache_used,
       file_cache_writes,
       file_cache_hit_ratio
FROM lfc_values;

alter table neon_stat_file_cache
    owner to cloud_admin;

grant select on neon_stat_file_cache to pg_monitor;

